//! Inline parser for Markdown.
//!
//! Uses a three-phase approach for efficiency:
//! 1. Mark Collection: Single pass collecting delimiter positions
//! 2. Mark Resolution: Process by precedence (code spans → links → emphasis)
//! 3. Event Emission: Walk resolved marks and emit events

mod code_span;
mod emphasis;
pub mod event;
mod highlight;
mod links;
pub mod marks;
mod math;
mod simd;
mod strikethrough;
mod subscript;
mod superscript;

#[cfg(test)]
std::thread_local! {
    static RANGE_PROBES: std::cell::Cell<[usize; 3]> = const { std::cell::Cell::new([0; 3]) };
}

#[cfg(test)]
#[derive(Clone, Copy, Debug)]
enum RangeProbe {
    CodeOpenerInHtml,
    AutolinkInCode,
    HtmlInCode,
}

#[cfg(test)]
fn record_range_probe(site: RangeProbe) {
    let mut probes = RANGE_PROBES.get();
    probes[site as usize] += 1;
    RANGE_PROBES.set(probes);
}

pub use event::InlineEvent;
pub use links::AutolinkLiteralKind;

use crate::footnote::FootnoteStore;
use crate::limits::{ResourceLimit, ResourceLimitReport};
use crate::link_ref::LinkRefStore;
use crate::range::assert_input_size;
use crate::{InputSizeError, Range};
use code_span::{CodeSpan, extract_code_spans, resolve_code_spans};
use emphasis::{EmphasisMatch, EmphasisStacks, resolve_emphasis_with_stacks_into};
use highlight::{HighlightMatch, resolve_highlight_into};
use links::{
    Autolink, AutolinkLiteral, Link, RefLink, ReferenceResolutionBudget,
    find_autolink_literals_into, find_autolinks_into, resolve_links_into_with_limits,
    resolve_reference_links_into,
};
use marks::{
    Mark, MarkBuffer, MarkSummary, collect_marks, collect_marks_highlight,
    collect_marks_highlight_superscript, collect_marks_superscript, flags,
};
use math::{MathSpan, resolve_math_spans_into};
use memchr::memchr;
use strikethrough::{StrikethroughMatch, resolve_strikethrough_into};
use subscript::{SubscriptMatch, resolve_subscript_into};
use superscript::{SuperscriptMatch, resolve_superscript_into};

/// Inline parser state.
pub struct InlineParser {
    /// Reusable mark buffer.
    mark_buffer: MarkBuffer,
    open_brackets: Vec<(u32, bool)>,
    close_brackets: Vec<u32>,
    autolinks: Vec<Autolink>,
    html_spans: Vec<HtmlSpan>,
    html_ranges: Vec<(u32, u32)>,
    link_dest_ranges: Vec<(u32, u32)>,
    autolink_ranges: Vec<(u32, u32)>,
    code_spans: Vec<CodeSpan>,
    link_boundaries: Vec<(u32, u32)>,
    resolved_links: Vec<Link>,
    link_formed_opens: Vec<bool>,
    link_inactive_opens: Vec<bool>,
    link_used_closes: Vec<bool>,
    ref_links: Vec<RefLink>,
    ref_label_buf: String,
    ref_formed_opens: Vec<bool>,
    ref_used_closes: Vec<bool>,
    ref_occupied: Vec<(u32, u32)>,
    ref_matching_closes: Vec<Option<usize>>,
    ref_matching_stack: Vec<usize>,
    ref_candidates: Vec<Option<links::RefCandidate>>,
    ref_candidate_prefix: Vec<usize>,
    ref_work_budget: ReferenceResolutionBudget,
    autolink_literals: Vec<AutolinkLiteral>,
    emphasis_stacks: EmphasisStacks,
    emphasis_matches: Vec<EmphasisMatch>,
    strikethrough_matches: Vec<StrikethroughMatch>,
    // Shared by sequential extension resolvers; each clears its opener stack.
    extension_openers: Vec<usize>,
    subscript_matches: Vec<SubscriptMatch>,
    superscript_matches: Vec<SuperscriptMatch>,
    highlight_matches: Vec<HighlightMatch>,
    al_code_span_ranges: Vec<(u32, u32)>,
    al_link_ranges: Vec<(u32, u32)>,
    emit_points: Vec<EmitPoint>,
    emit_suppress_ranges: Vec<(u32, u32)>,
    html_code_ranges: Vec<(usize, usize)>,
    html_autolink_ranges: Vec<(usize, usize)>,
    footnote_refs: Vec<FootnoteRef>,
    inline_footnotes: Vec<InlineFootnote>,
    inline_footnote_brackets: Vec<(u32, Option<u32>)>,
    math_spans: Vec<MathSpan>,
    resource_limits: ResourceLimitReport,
}

impl InlineParser {
    /// Create a new inline parser.
    pub fn new() -> Self {
        Self {
            mark_buffer: MarkBuffer::new(),
            open_brackets: Vec::new(),
            close_brackets: Vec::new(),
            autolinks: Vec::new(),
            html_spans: Vec::new(),
            html_ranges: Vec::new(),
            link_dest_ranges: Vec::new(),
            autolink_ranges: Vec::new(),
            code_spans: Vec::new(),
            link_boundaries: Vec::new(),
            resolved_links: Vec::new(),
            link_formed_opens: Vec::new(),
            link_inactive_opens: Vec::new(),
            link_used_closes: Vec::new(),
            ref_links: Vec::new(),
            ref_label_buf: String::new(),
            ref_formed_opens: Vec::new(),
            ref_used_closes: Vec::new(),
            ref_occupied: Vec::new(),
            ref_matching_closes: Vec::new(),
            ref_matching_stack: Vec::new(),
            ref_candidates: Vec::new(),
            ref_candidate_prefix: Vec::new(),
            ref_work_budget: ReferenceResolutionBudget::new(),
            autolink_literals: Vec::new(),
            emphasis_stacks: EmphasisStacks::default(),
            emphasis_matches: Vec::new(),
            strikethrough_matches: Vec::new(),
            extension_openers: Vec::new(),
            subscript_matches: Vec::new(),
            superscript_matches: Vec::new(),
            highlight_matches: Vec::new(),
            al_code_span_ranges: Vec::new(),
            al_link_ranges: Vec::new(),
            emit_points: Vec::new(),
            emit_suppress_ranges: Vec::new(),
            html_code_ranges: Vec::new(),
            html_autolink_ranges: Vec::new(),
            footnote_refs: Vec::new(),
            inline_footnotes: Vec::new(),
            inline_footnote_brackets: Vec::new(),
            math_spans: Vec::new(),
            resource_limits: ResourceLimitReport::default(),
        }
    }

    /// Parse inline content and emit events.
    ///
    /// # Panics
    ///
    /// Panics when `text` exceeds [`crate::MAX_INPUT_BYTES`]. Use
    /// [`Self::try_parse`] to handle the limit as an error.
    pub fn parse(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        allow_html: bool,
        events: &mut Vec<InlineEvent>,
    ) {
        self.try_parse(text, link_refs, allow_html, events)
            .unwrap_or_else(|error| panic!("{error}"));
    }

    /// Parse inline content without panicking for oversized input.
    pub fn try_parse(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        allow_html: bool,
        events: &mut Vec<InlineEvent>,
    ) -> Result<(), InputSizeError> {
        crate::validate_input_size(text.len())?;
        self.begin_document();
        self.parse_with_options_in_document(
            text, link_refs, allow_html, true, false, false, false, true, false, false, None,
            events,
        );
        Ok(())
    }

    /// Parse inline Markdown with opt-in MDX expressions and JSX tags.
    ///
    /// This keeps the normal Markdown inline grammar intact while exposing
    /// well-delimited inline MDX constructs as source-ranged [`InlineEvent`]
    /// variants. Code spans and backslash escapes retain their normal
    /// precedence, and malformed MDX remains plain text.
    ///
    /// Inline HTML is intentionally disabled for this mode so valid JSX tags
    /// are not consumed as raw HTML before MDX recognition.
    ///
    /// # Panics
    ///
    /// Panics when `text` exceeds [`crate::MAX_INPUT_BYTES`]. Use
    /// [`Self::try_parse_mdx`] to handle the limit as an error.
    #[cfg(feature = "mdx")]
    pub fn parse_mdx(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        events: &mut Vec<InlineEvent>,
    ) {
        self.try_parse_mdx(text, link_refs, events)
            .unwrap_or_else(|error| panic!("{error}"));
    }

    /// Parse inline Markdown with MDX support without panicking for oversized
    /// input.
    #[cfg(feature = "mdx")]
    pub fn try_parse_mdx(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        events: &mut Vec<InlineEvent>,
    ) -> Result<(), InputSizeError> {
        crate::validate_input_size(text.len())?;
        self.begin_document();
        self.parse_mdx_in_document(text, link_refs, events);
        Ok(())
    }

    /// Begin a document-level inline parsing session.
    ///
    /// Public parsing methods call this automatically. Renderers that parse
    /// multiple paragraphs with one reusable parser call it once per document
    /// so reference-resolution work remains bounded for the whole document.
    pub(crate) fn begin_document(&mut self) {
        self.ref_work_budget.reset();
        self.resource_limits = ResourceLimitReport::default();
    }

    /// Return resource-limit fallbacks used in the current document.
    ///
    /// Public parse methods reset this report before parsing. Document
    /// renderers accumulate limits across every paragraph in the document.
    #[must_use]
    pub const fn resource_limits(&self) -> ResourceLimitReport {
        self.resource_limits
    }

    /// Parse inline Markdown with opt-in MDX expressions as part of an active
    /// document-level parsing session.
    #[cfg(feature = "mdx")]
    pub(crate) fn parse_mdx_in_document(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        events: &mut Vec<InlineEvent>,
    ) {
        let new_events_start = events.len();
        self.parse_with_options_in_document(
            text, link_refs, false, true, false, false, false, true, false, false, None, events,
        );
        split_mdx_text_events(text, events, new_events_start);
    }

    /// Parse inline content with configurable inline extensions.
    ///
    /// # Panics
    ///
    /// Panics when `text` exceeds [`crate::MAX_INPUT_BYTES`]. Use
    /// [`Self::try_parse_with_options`] to handle the limit as an error.
    #[allow(clippy::too_many_arguments)]
    pub fn parse_with_options(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        allow_html: bool,
        strikethrough: bool,
        highlight: bool,
        superscript: bool,
        subscript: bool,
        autolink_literals: bool,
        math: bool,
        inline_footnotes: bool,
        footnote_store: Option<&FootnoteStore>,
        events: &mut Vec<InlineEvent>,
    ) {
        self.try_parse_with_options(
            text,
            link_refs,
            allow_html,
            strikethrough,
            highlight,
            superscript,
            subscript,
            autolink_literals,
            math,
            inline_footnotes,
            footnote_store,
            events,
        )
        .unwrap_or_else(|error| panic!("{error}"));
    }

    /// Parse inline content with configurable extensions without panicking for
    /// oversized input.
    #[allow(clippy::too_many_arguments)]
    pub fn try_parse_with_options(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        allow_html: bool,
        strikethrough: bool,
        highlight: bool,
        superscript: bool,
        subscript: bool,
        autolink_literals: bool,
        math: bool,
        inline_footnotes: bool,
        footnote_store: Option<&FootnoteStore>,
        events: &mut Vec<InlineEvent>,
    ) -> Result<(), InputSizeError> {
        crate::validate_input_size(text.len())?;
        self.begin_document();
        self.parse_with_options_in_document(
            text,
            link_refs,
            allow_html,
            strikethrough,
            highlight,
            superscript,
            subscript,
            autolink_literals,
            math,
            inline_footnotes,
            footnote_store,
            events,
        );
        Ok(())
    }

    /// Parse inline content as part of an active document-level parsing session.
    #[allow(clippy::too_many_arguments)]
    pub(crate) fn parse_with_options_in_document(
        &mut self,
        text: &[u8],
        link_refs: Option<&LinkRefStore>,
        allow_html: bool,
        strikethrough: bool,
        highlight: bool,
        superscript: bool,
        subscript: bool,
        autolink_literals: bool,
        math: bool,
        inline_footnotes: bool,
        footnote_store: Option<&FootnoteStore>,
        events: &mut Vec<InlineEvent>,
    ) {
        // Every source offset produced by the inline pipeline is narrowed to
        // `u32`; keep that invariant at this shared entry point for reusable
        // parser sessions as well as the public `try_*` methods.
        assert_input_size(text.len());
        #[cfg(feature = "profiling")]
        let event_start = events.len();
        let may_have_inline_footnotes = inline_footnotes && has_inline_footnote_candidate(text);
        let caret_syntax = superscript || may_have_inline_footnotes;
        let has_specials = if highlight && caret_syntax {
            has_inline_specials_highlight_superscript(text)
        } else if highlight {
            has_inline_specials_highlight(text)
        } else if caret_syntax {
            has_inline_specials_superscript(text)
        } else {
            has_inline_specials(text)
        };

        // Check for potential autolink literal triggers when enabled
        let may_have_autolinks = autolink_literals && has_autolink_candidates(text);

        if !has_specials && !may_have_autolinks {
            if !text.is_empty() {
                events.push(InlineEvent::Text(Range::from_usize(0, text.len())));
            }
            #[cfg(feature = "profiling")]
            crate::profiling::record_inline_parse(
                text.len(),
                events.len() - event_start,
                0,
                self.mark_buffer.capacity(),
                0,
                self.emit_points.capacity(),
                true,
            );
            return;
        }

        // Phase 1: Collect marks
        self.mark_buffer.reserve_for_text(text.len());
        let summary = if has_specials {
            if highlight && caret_syntax {
                collect_marks_highlight_superscript(text, &mut self.mark_buffer)
            } else if highlight {
                collect_marks_highlight(text, &mut self.mark_buffer)
            } else if caret_syntax {
                collect_marks_superscript(text, &mut self.mark_buffer)
            } else {
                collect_marks(text, &mut self.mark_buffer)
            }
        } else {
            self.mark_buffer.clear();
            MarkSummary::default()
        };

        if self.mark_buffer.limit_exceeded() {
            self.resource_limits.record(ResourceLimit::InlineMarks);
        }
        if self.mark_buffer.code_span_limit_exceeded() {
            self.resource_limits
                .record(ResourceLimit::CodeSpanBackticks);
        }

        if self.mark_buffer.is_empty() && !may_have_autolinks {
            // No special characters and no autolink candidates, emit as plain text
            if !text.is_empty() {
                events.push(InlineEvent::Text(Range::from_usize(0, text.len())));
            }
            #[cfg(feature = "profiling")]
            crate::profiling::record_inline_parse(
                text.len(),
                events.len() - event_start,
                self.mark_buffer.len(),
                self.mark_buffer.capacity(),
                0,
                self.emit_points.capacity(),
                true,
            );
            return;
        }

        // Phase 2: Resolve marks by precedence
        // First: autolinks + raw HTML (skip if no '<' present)
        let has_lt = summary.has_less_than();
        self.autolinks.clear();
        if has_lt {
            find_autolinks_into(text, &mut self.autolinks);
        }

        // Second: raw inline HTML (ignore code spans for now; we'll filter after resolving them)
        self.html_spans.clear();
        if has_lt && allow_html {
            find_html_spans_into(
                text,
                &[],
                &self.autolinks,
                &mut self.html_code_ranges,
                &mut self.html_autolink_ranges,
                &mut self.html_spans,
            );
        }
        self.html_ranges.clear();
        self.html_ranges.reserve(self.html_spans.len());
        self.html_ranges
            .extend(self.html_spans.iter().map(|s| (s.start, s.end)));

        // Third: code spans (highest precedence, but should not start inside HTML tags)
        if summary.has_code() {
            resolve_code_spans(self.mark_buffer.marks_mut(), text, &self.html_ranges);
        }

        // Get code span ranges for filtering
        self.code_spans.clear();
        if summary.has_code() {
            self.code_spans
                .extend(extract_code_spans(self.mark_buffer.marks()));
        }
        filter_html_spans_in_code_spans(&mut self.html_spans, &self.code_spans);

        // Math spans (after code spans, before links; gated on math option)
        if math && summary.has_math() {
            resolve_math_spans_into(self.mark_buffer.marks_mut(), text, &mut self.math_spans);
        } else {
            self.math_spans.clear();
        }

        filter_autolinks_in_code_spans(&mut self.autolinks, &self.code_spans);

        // Fourth: collect bracket positions and detect inline delimiter candidates in one pass
        Self::collect_brackets(
            self.mark_buffer.marks(),
            &mut self.open_brackets,
            &mut self.close_brackets,
        );
        let has_brackets = !self.open_brackets.is_empty() && !self.close_brackets.is_empty();
        self.open_brackets
            .retain(|&(pos, _)| !pos_in_spans(pos, &self.html_spans));
        // Filter out close brackets that are inside autolinks - they can't close links
        self.close_brackets.retain(|&pos| {
            !self
                .autolinks
                .iter()
                .any(|al| pos > al.start && pos < al.end)
                && !pos_in_spans(pos, &self.html_spans)
        });
        let has_inline_link_candidate = has_brackets && has_inline_link_opener(text);
        if has_inline_link_candidate {
            if resolve_links_into_with_limits(
                text,
                &self.open_brackets,
                &self.close_brackets,
                &mut self.resolved_links,
                &mut self.link_formed_opens,
                &mut self.link_inactive_opens,
                &mut self.link_used_closes,
            ) {
                self.resource_limits
                    .record(ResourceLimit::LinkDestinationParentheses);
            }
        } else {
            self.resolved_links.clear();
        }
        let resolved_links = &self.resolved_links;

        if has_brackets {
            if let Some(defs) = link_refs.filter(|defs| !defs.is_empty()) {
                resolve_reference_links_into(
                    text,
                    &self.open_brackets,
                    &self.close_brackets,
                    resolved_links,
                    defs,
                    &mut self.ref_links,
                    &mut self.ref_label_buf,
                    &mut self.ref_formed_opens,
                    &mut self.ref_used_closes,
                    &mut self.ref_occupied,
                    &mut self.ref_matching_closes,
                    &mut self.ref_matching_stack,
                    &mut self.ref_candidates,
                    &mut self.ref_candidate_prefix,
                    &mut self.ref_work_budget,
                );
                if self.ref_work_budget.limit_exceeded() {
                    self.resource_limits
                        .record(ResourceLimit::ReferenceResolutionWork);
                }
            } else {
                self.ref_links.clear();
            }
            filter_html_spans_in_link_destinations(&mut self.html_spans, resolved_links);
        } else {
            self.ref_links.clear();
        }
        let resolved_ref_links = &self.ref_links;

        self.link_dest_ranges.clear();
        self.link_dest_ranges
            .extend(resolved_links.iter().filter_map(|link| {
                let start = link.text_end + 1;
                let end = link.end;
                (start < end).then_some((start, end))
            }));

        self.autolink_ranges.clear();
        self.autolink_ranges
            .extend(self.autolinks.iter().map(|al| (al.start, al.end)));

        // Fifth: footnote references (`[^label]`)
        self.footnote_refs.clear();
        if let Some(fn_store) = footnote_store {
            Self::resolve_footnote_refs(
                text,
                &self.open_brackets,
                &self.close_brackets,
                resolved_links,
                resolved_ref_links,
                &self.code_spans,
                fn_store,
                &mut self.footnote_refs,
            );
        }

        // Sixth: Pandoc-style inline footnotes (`^[...]`). They deliberately
        // precede superscript so the opening caret cannot be consumed by
        // `^text^`.
        self.inline_footnotes.clear();
        if may_have_inline_footnotes {
            Self::resolve_inline_footnotes(
                text,
                self.mark_buffer.marks_mut(),
                resolved_links,
                resolved_ref_links,
                &self.code_spans,
                &self.html_spans,
                &self.autolinks,
                &self.link_dest_ranges,
                &mut self.inline_footnotes,
                &mut self.inline_footnote_brackets,
            );
        }

        // Seventh: emphasis (lowest precedence)
        // Pass link and autolink boundaries so emphasis can't cross them
        self.link_boundaries.clear();
        self.link_boundaries.reserve(
            resolved_links.len()
                + resolved_ref_links.len()
                + self.autolinks.len()
                + self.html_spans.len()
                + self.footnote_refs.len()
                + self.inline_footnotes.len(),
        );
        self.link_boundaries
            .extend(resolved_links.iter().map(|l| (l.start, l.text_end)));
        for link in resolved_ref_links {
            self.link_boundaries.push((link.start, link.text_end));
        }
        // Also include autolinks - delimiters inside <url> should not form emphasis
        for autolink in &self.autolinks {
            self.link_boundaries.push((autolink.start, autolink.end));
        }
        // Also include raw HTML spans
        for span in &self.html_spans {
            self.link_boundaries.push((span.start, span.end));
        }
        // Also include resolved footnote references
        for fref in &self.footnote_refs {
            self.link_boundaries.push((fref.start, fref.end));
        }
        for inline_note in &self.inline_footnotes {
            self.link_boundaries
                .push((inline_note.start, inline_note.end));
        }
        normalize_link_boundaries(&mut self.link_boundaries);
        let emphasis_matches = if summary.has_emphasis() {
            resolve_emphasis_with_stacks_into(
                self.mark_buffer.marks_mut(),
                &self.link_boundaries,
                &mut self.emphasis_stacks,
                &mut self.emphasis_matches,
            );
            self.emphasis_matches.as_slice()
        } else {
            self.emphasis_matches.clear();
            &[]
        };

        // Seventh: strikethrough (after emphasis, since they share the mark buffer)
        if summary.has_tilde() && strikethrough {
            resolve_strikethrough_into(
                self.mark_buffer.marks_mut(),
                &self.link_boundaries,
                &mut self.strikethrough_matches,
                &mut self.extension_openers,
            );
        } else {
            self.strikethrough_matches.clear();
        }
        let strikethrough_matches = self.strikethrough_matches.as_slice();

        // Eighth: subscript (after strikethrough, since they share `~`)
        if summary.has_tilde() && subscript {
            resolve_subscript_into(
                self.mark_buffer.marks_mut(),
                text,
                &self.link_boundaries,
                &self.link_dest_ranges,
                &mut self.subscript_matches,
                &mut self.extension_openers,
            );
        } else {
            self.subscript_matches.clear();
        }
        let subscript_matches = self.subscript_matches.as_slice();

        // Ninth: superscript
        if summary.has_superscript() && superscript {
            resolve_superscript_into(
                self.mark_buffer.marks_mut(),
                text,
                &self.link_boundaries,
                &self.link_dest_ranges,
                &mut self.superscript_matches,
                &mut self.extension_openers,
            );
        } else {
            self.superscript_matches.clear();
        }
        let superscript_matches = self.superscript_matches.as_slice();

        // Tenth: highlight/mark
        if summary.has_highlight() && highlight {
            resolve_highlight_into(
                self.mark_buffer.marks_mut(),
                text,
                &self.link_boundaries,
                &self.link_dest_ranges,
                &mut self.highlight_matches,
                &mut self.extension_openers,
            );
        } else {
            self.highlight_matches.clear();
        }
        let highlight_matches = self.highlight_matches.as_slice();

        // Eleventh: autolink literals (bare URLs, www, emails)
        if may_have_autolinks {
            // Build code span ranges for overlap checking (reuse Vec)
            self.al_code_span_ranges.clear();
            self.al_code_span_ranges.extend(
                self.code_spans
                    .iter()
                    .map(|cs| (cs.opener_pos, cs.closer_end)),
            );
            // Build link ranges (inline links + ref links) (reuse Vec)
            self.al_link_ranges.clear();
            self.al_link_ranges
                .reserve(resolved_links.len() + resolved_ref_links.len());
            for link in resolved_links {
                self.al_link_ranges.push((link.start, link.end));
            }
            for link in resolved_ref_links {
                self.al_link_ranges.push((link.start, link.end));
            }
            find_autolink_literals_into(
                text,
                &self.al_code_span_ranges,
                &self.html_ranges,
                &self.autolink_ranges,
                &self.al_link_ranges,
                &mut self.autolink_literals,
            );
        } else {
            self.autolink_literals.clear();
        }

        // Phase 3: Emit events
        let marks = self.mark_buffer.marks();
        Self::emit_events(
            marks,
            text,
            &self.code_spans,
            &self.math_spans,
            emphasis_matches,
            strikethrough_matches,
            subscript_matches,
            superscript_matches,
            highlight_matches,
            &self.autolink_literals,
            resolved_links,
            resolved_ref_links,
            &self.autolinks,
            &self.html_spans,
            &self.link_dest_ranges,
            &self.autolink_ranges,
            &self.html_ranges,
            &self.footnote_refs,
            &self.inline_footnotes,
            &mut self.emit_points,
            &mut self.emit_suppress_ranges,
            events,
        );
        #[cfg(feature = "profiling")]
        crate::profiling::record_inline_parse(
            text.len(),
            events.len() - event_start,
            self.mark_buffer.len(),
            self.mark_buffer.capacity(),
            self.emit_points.len(),
            self.emit_points.capacity(),
            false,
        );
    }

    /// Resolve footnote references: `[^label]` patterns not consumed by links/images.
    #[allow(clippy::too_many_arguments)]
    fn resolve_footnote_refs(
        text: &[u8],
        open_brackets: &[(u32, bool)],
        close_brackets: &[u32],
        resolved_links: &[Link],
        resolved_ref_links: &[RefLink],
        code_spans: &[CodeSpan],
        footnote_store: &FootnoteStore,
        out: &mut Vec<FootnoteRef>,
    ) {
        out.clear();

        // For each open bracket, check if it's followed by `^label]`
        for &(open_pos, is_image) in open_brackets {
            if is_image {
                continue; // `![^` is an image, not a footnote
            }

            // Check if this bracket is inside a code span
            let in_code = code_spans
                .iter()
                .any(|cs| open_pos >= cs.opener_pos && open_pos < cs.closer_end);
            if in_code {
                continue;
            }

            // Check if this bracket is already consumed by a link/image
            let in_link = resolved_links.iter().any(|l| l.start == open_pos)
                || resolved_ref_links.iter().any(|l| l.start == open_pos);
            if in_link {
                continue;
            }

            // Check for `^` after `[`
            let caret_pos = (open_pos + 1) as usize;
            if caret_pos >= text.len() || text[caret_pos] != b'^' {
                continue;
            }

            // Read label: alphanumeric, dash, underscore
            let label_start = caret_pos + 1;
            let mut label_end = label_start;
            while label_end < text.len() {
                let b = text[label_end];
                if b.is_ascii_alphanumeric() || b == b'-' || b == b'_' {
                    label_end += 1;
                } else {
                    break;
                }
            }

            if label_end == label_start {
                continue; // Empty label
            }

            // Must be followed by `]`
            if label_end >= text.len() || text[label_end] != b']' {
                continue;
            }

            // Check that this `]` is in the close_brackets list (validates it's not escaped)
            let close_pos = label_end as u32;
            if !close_brackets.contains(&close_pos) {
                continue;
            }

            let label_bytes = &text[label_start..label_end];
            if let Some(idx) = footnote_store.get_index_bytes(label_bytes) {
                out.push(FootnoteRef {
                    start: open_pos,
                    end: close_pos + 1,
                    def_index: idx as u32,
                });
            }
        }
    }

    /// Resolve Pandoc-style inline notes: `^[single paragraph content]`.
    #[allow(clippy::too_many_arguments)]
    fn resolve_inline_footnotes(
        text: &[u8],
        marks: &mut [Mark],
        resolved_links: &[Link],
        resolved_ref_links: &[RefLink],
        code_spans: &[CodeSpan],
        html_spans: &[HtmlSpan],
        autolinks: &[Autolink],
        link_dest_ranges: &[(u32, u32)],
        out: &mut Vec<InlineFootnote>,
        bracket_stack: &mut Vec<(u32, Option<u32>)>,
    ) {
        out.clear();
        bracket_stack.clear();

        let mut pos = 0usize;
        let mut code_span_index = 0usize;
        while pos < text.len() {
            while code_span_index < code_spans.len()
                && pos as u32 >= code_spans[code_span_index].closer_end
            {
                code_span_index += 1;
            }
            if let Some(span) = code_spans.get(code_span_index)
                && pos as u32 >= span.opener_pos
                && (pos as u32) < span.closer_end
            {
                pos = span.closer_end as usize;
                continue;
            }

            let bracket_mark = matches!(text[pos], b'[' | b']')
                .then(|| {
                    marks
                        .binary_search_by_key(&(pos as u32), |mark| mark.pos)
                        .ok()
                })
                .flatten();
            if bracket_mark.is_some() {
                if text[pos] == b'[' {
                    let start = pos.checked_sub(1).and_then(|caret_pos| {
                        let mark_index = marks
                            .binary_search_by_key(&(caret_pos as u32), |mark| mark.pos)
                            .ok()?;
                        let candidate = marks[mark_index];
                        if candidate.ch != b'^'
                            || candidate.len() != 1
                            || candidate.flags & (flags::IN_CODE | flags::RESOLVED) != 0
                            || resolved_links
                                .iter()
                                .any(|link| candidate.pos >= link.start && candidate.pos < link.end)
                            || resolved_ref_links
                                .iter()
                                .any(|link| candidate.pos >= link.start && candidate.pos < link.end)
                            || html_spans
                                .iter()
                                .any(|span| candidate.pos >= span.start && candidate.pos < span.end)
                            || autolinks.iter().any(|autolink| {
                                candidate.pos >= autolink.start && candidate.pos < autolink.end
                            })
                            || link_dest_ranges.iter().any(|&(range_start, range_end)| {
                                candidate.pos >= range_start && candidate.pos < range_end
                            })
                        {
                            None
                        } else {
                            Some(candidate.pos)
                        }
                    });
                    bracket_stack.push((pos as u32, start));
                } else if let Some((open_bracket, Some(start))) = bracket_stack.pop() {
                    let content_start = open_bracket + 1;
                    let content_end = pos as u32;
                    if let Ok(mark_index) = marks.binary_search_by_key(&start, |mark| mark.pos) {
                        marks[mark_index].resolve();
                    }
                    if !text[content_start as usize..content_end as usize]
                        .iter()
                        .all(|byte| byte.is_ascii_whitespace())
                    {
                        out.push(InlineFootnote {
                            start,
                            end: content_end + 1,
                            content_start,
                            content_end,
                        });
                    }
                }
            }
            pos += 1;
        }
    }

    /// Collect bracket positions for link parsing after code-span resolution.
    fn collect_brackets(
        marks: &[Mark],
        open_brackets: &mut Vec<(u32, bool)>,
        close_brackets: &mut Vec<u32>,
    ) {
        let estimated = (marks.len() / 4).max(4);
        open_brackets.clear();
        close_brackets.clear();
        open_brackets.reserve(estimated);
        close_brackets.reserve(estimated);

        for mark in marks {
            // Skip brackets inside code spans
            if mark.flags & flags::IN_CODE != 0 && mark.ch != b'[' {
                continue;
            }

            match mark.ch {
                b'[' => {
                    // IN_CODE flag repurposed for "is_image" for brackets
                    let is_image = mark.flags & flags::IN_CODE != 0;
                    open_brackets.push((mark.pos, is_image));
                }
                b']' => {
                    close_brackets.push(mark.pos);
                }
                _ => {}
            }
        }
    }

    /// Emit events based on resolved marks.
    #[allow(clippy::too_many_arguments)]
    fn emit_events(
        marks: &[Mark],
        text: &[u8],
        code_spans: &[CodeSpan],
        math_spans: &[MathSpan],
        emphasis_matches: &[EmphasisMatch],
        strikethrough_matches: &[StrikethroughMatch],
        subscript_matches: &[SubscriptMatch],
        superscript_matches: &[SuperscriptMatch],
        highlight_matches: &[HighlightMatch],
        autolink_literals: &[AutolinkLiteral],
        resolved_links: &[Link],
        resolved_ref_links: &[RefLink],
        autolinks: &[Autolink],
        html_spans: &[HtmlSpan],
        link_dest_ranges: &[(u32, u32)],
        autolink_ranges: &[(u32, u32)],
        html_ranges: &[(u32, u32)],
        footnote_refs: &[FootnoteRef],
        inline_footnotes: &[InlineFootnote],
        emit_points: &mut Vec<EmitPoint>,
        suppress_ranges: &mut Vec<(u32, u32)>,
        events: &mut Vec<InlineEvent>,
    ) {
        let mut pos = 0u32;
        let text_len = text.len() as u32;

        let mut link_dest_idx = 0usize;
        let mut autolink_idx = 0usize;
        let mut html_idx = 0usize;
        let mut autolink_span_idx = 0usize;

        // Build sorted list of events to emit
        let estimated_events = marks.len()
            + (code_spans.len() * 3)
            + (resolved_links.len() * 4)
            + (resolved_ref_links.len() * 4)
            + autolinks.len()
            + autolink_literals.len()
            + html_spans.len()
            + (emphasis_matches.len() * 2)
            + (strikethrough_matches.len() * 2)
            + (subscript_matches.len() * 2)
            + (superscript_matches.len() * 2)
            + (highlight_matches.len() * 2);
        emit_points.clear();
        emit_points.reserve(estimated_events.max(8));
        events.reserve(estimated_events.max(8) + 4);

        // Other resolved constructs can overlap code boundaries or suppress
        // events within them. Keep the original three-point sequence in those
        // cases, including its closing-boundary behavior and public event order.
        let fuse_code = resolved_links.is_empty()
            && resolved_ref_links.is_empty()
            && math_spans.is_empty()
            && footnote_refs.is_empty()
            && inline_footnotes.is_empty();
        // Add code span events (filter out spans whose opener is inside an autolink)
        for (index, span) in code_spans.iter().enumerate() {
            // Skip code spans whose opener starts inside an autolink
            let inside_autolink = !autolink_ranges.is_empty()
                && pos_in_ranges_u32(span.opener_pos, autolink_ranges, &mut autolink_span_idx);
            if inside_autolink {
                continue;
            }

            if fuse_code {
                emit_points.push(EmitPoint {
                    pos: span.opener_pos,
                    kind: EmitKind::CodeSpan {
                        index: index as u32,
                    },
                    end: span.closer_pos,
                });
                emit_points.push(EmitPoint {
                    pos: span.closer_pos,
                    kind: EmitKind::CodeSpanEnd,
                    end: span.closer_end,
                });
            } else {
                emit_points.push(EmitPoint {
                    pos: span.opener_pos,
                    kind: EmitKind::CodeSpanStart,
                    end: span.opener_end,
                });
                emit_points.push(EmitPoint {
                    pos: span.closer_pos,
                    kind: EmitKind::CodeSpanEnd,
                    end: span.closer_end,
                });
                // Code content
                let (content_start, content_end) = span.content_range();
                emit_points.push(EmitPoint {
                    pos: content_start,
                    kind: EmitKind::CodeContent(content_end),
                    end: content_end,
                });
            }
        }

        // Add math span events
        for (index, span) in math_spans.iter().enumerate() {
            if span.is_display {
                emit_points.push(EmitPoint {
                    pos: span.opener_pos,
                    kind: EmitKind::MathDisplay {
                        index: index as u32,
                    },
                    end: span.closer_end,
                });
            } else {
                emit_points.push(EmitPoint {
                    pos: span.opener_pos,
                    kind: EmitKind::MathInline {
                        index: index as u32,
                    },
                    end: span.closer_end,
                });
            }
        }

        // Add link events
        for (link_index, link) in resolved_links.iter().enumerate() {
            if link.is_image {
                emit_points.push(EmitPoint {
                    pos: link.start,
                    kind: EmitKind::ImageStart {
                        link_index: link_index as u32,
                    },
                    end: link.start + 2, // ![
                });
                emit_points.push(EmitPoint {
                    pos: link.text_end,
                    kind: EmitKind::ImageEnd,
                    end: link.end,
                });
            } else {
                emit_points.push(EmitPoint {
                    pos: link.start,
                    kind: EmitKind::LinkStart {
                        link_index: link_index as u32,
                    },
                    end: link.start + 1, // [
                });
                emit_points.push(EmitPoint {
                    pos: link.text_end,
                    kind: EmitKind::LinkEnd,
                    end: link.end,
                });
            }
        }

        // Add reference-style link events
        for link in resolved_ref_links {
            if link.is_image {
                emit_points.push(EmitPoint {
                    pos: link.start,
                    kind: EmitKind::ImageStartRef {
                        def_index: link.def_index as u32,
                    },
                    end: link.start + 2, // ![
                });
                emit_points.push(EmitPoint {
                    pos: link.text_end,
                    kind: EmitKind::ImageEnd,
                    end: link.end,
                });
            } else {
                emit_points.push(EmitPoint {
                    pos: link.start,
                    kind: EmitKind::LinkStartRef {
                        def_index: link.def_index as u32,
                    },
                    end: link.start + 1, // [
                });
                emit_points.push(EmitPoint {
                    pos: link.text_end,
                    kind: EmitKind::LinkEnd,
                    end: link.end,
                });
            }
        }
        // Add autolink events
        for (index, autolink) in autolinks.iter().enumerate() {
            if autolink.is_email {
                emit_points.push(EmitPoint {
                    pos: autolink.start,
                    kind: EmitKind::AutolinkEmail {
                        index: index as u32,
                    },
                    end: autolink.end,
                });
            } else {
                emit_points.push(EmitPoint {
                    pos: autolink.start,
                    kind: EmitKind::AutolinkUrl {
                        index: index as u32,
                    },
                    end: autolink.end,
                });
            }
        }

        // Add raw HTML events
        for span in html_spans {
            emit_points.push(EmitPoint {
                pos: span.start,
                kind: EmitKind::HtmlRaw { end: span.end },
                end: span.end,
            });
        }

        // Add autolink literal events
        for al in autolink_literals {
            emit_points.push(EmitPoint {
                pos: al.start,
                kind: EmitKind::AutolinkLiteral { kind: al.kind },
                end: al.end,
            });
        }

        // Add emphasis events
        for m in emphasis_matches {
            let is_strong = m.count == 2;

            if is_strong {
                emit_points.push(EmitPoint {
                    pos: m.opener_start,
                    kind: EmitKind::StrongStart,
                    end: m.opener_end,
                });
                emit_points.push(EmitPoint {
                    pos: m.closer_start,
                    kind: EmitKind::StrongEnd,
                    end: m.closer_end,
                });
            } else {
                emit_points.push(EmitPoint {
                    pos: m.opener_start,
                    kind: EmitKind::EmphasisStart,
                    end: m.opener_end,
                });
                emit_points.push(EmitPoint {
                    pos: m.closer_start,
                    kind: EmitKind::EmphasisEnd,
                    end: m.closer_end,
                });
            }
        }

        // Add strikethrough events
        for m in strikethrough_matches {
            emit_points.push(EmitPoint {
                pos: m.opener_start,
                kind: EmitKind::StrikethroughStart,
                end: m.opener_end,
            });
            emit_points.push(EmitPoint {
                pos: m.closer_start,
                kind: EmitKind::StrikethroughEnd,
                end: m.closer_end,
            });
        }

        // Add subscript events
        for m in subscript_matches {
            emit_points.push(EmitPoint {
                pos: m.opener_start,
                kind: EmitKind::SubscriptStart,
                end: m.opener_end,
            });
            emit_points.push(EmitPoint {
                pos: m.closer_start,
                kind: EmitKind::SubscriptEnd,
                end: m.closer_end,
            });
        }

        // Add superscript events
        for m in superscript_matches {
            emit_points.push(EmitPoint {
                pos: m.opener_start,
                kind: EmitKind::SuperscriptStart,
                end: m.opener_end,
            });
            emit_points.push(EmitPoint {
                pos: m.closer_start,
                kind: EmitKind::SuperscriptEnd,
                end: m.closer_end,
            });
        }

        // Add highlight events
        for m in highlight_matches {
            emit_points.push(EmitPoint {
                pos: m.opener_start,
                kind: EmitKind::HighlightStart,
                end: m.opener_end,
            });
            emit_points.push(EmitPoint {
                pos: m.closer_start,
                kind: EmitKind::HighlightEnd,
                end: m.closer_end,
            });
        }

        // Add footnote reference events
        for fref in footnote_refs {
            emit_points.push(EmitPoint {
                pos: fref.start,
                kind: EmitKind::FootnoteRef {
                    def_index: fref.def_index,
                },
                end: fref.end,
            });
        }

        for (index, inline_note) in inline_footnotes.iter().enumerate() {
            emit_points.push(EmitPoint {
                pos: inline_note.start,
                kind: EmitKind::InlineFootnote {
                    index: index as u32,
                },
                end: inline_note.end,
            });
        }

        // Add backslash escapes and hard breaks
        // Note: Hard breaks inside code spans should not be processed
        for mark in marks {
            // Skip marks inside code spans
            let in_code = mark.flags & flags::IN_CODE != 0;

            if mark.ch == b'\\' && mark.flags & flags::POTENTIAL_OPENER != 0 {
                // Check if mark is inside a link's destination area (the (...) part)
                // This includes URL, title, and any whitespace between them
                let in_link_dest = !link_dest_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, link_dest_ranges, &mut link_dest_idx);
                // Check if mark is inside an autolink
                let in_autolink = !autolink_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, autolink_ranges, &mut autolink_idx);
                let in_html = !html_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, html_ranges, &mut html_idx);

                let escaped_char = text[(mark.pos + 1) as usize];
                if escaped_char == b'\n' && !in_code && !in_autolink && !in_html {
                    // Backslash before newline is a hard break (but not in code or autolinks)
                    emit_points.push(EmitPoint {
                        pos: mark.pos,
                        kind: EmitKind::HardBreak,
                        end: mark.end,
                    });
                } else if !in_code && !in_link_dest && !in_autolink && !in_html {
                    // Skip escapes inside link URLs/titles and autolinks (they're processed by renderer)
                    emit_points.push(EmitPoint {
                        pos: mark.pos,
                        kind: EmitKind::Escape(escaped_char),
                        end: mark.end,
                    });
                }
            } else if mark.ch == b'\n' && mark.flags & flags::POTENTIAL_OPENER != 0 {
                let in_link_dest = !link_dest_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, link_dest_ranges, &mut link_dest_idx);
                let in_html = !html_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, html_ranges, &mut html_idx);
                if in_code || in_link_dest || in_html {
                    continue;
                }
                // Two spaces before newline is a hard break (but not in code or link destinations)
                emit_points.push(EmitPoint {
                    pos: mark.pos,
                    kind: EmitKind::HardBreak,
                    end: mark.end,
                });
            } else if mark.ch == b'\n' && mark.flags & flags::POTENTIAL_CLOSER != 0 {
                let in_link_dest = !link_dest_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, link_dest_ranges, &mut link_dest_idx);
                let in_html = !html_ranges.is_empty()
                    && pos_in_ranges_u32(mark.pos, html_ranges, &mut html_idx);
                if in_code || in_link_dest || in_html {
                    continue;
                }
                // Soft break (newline without 2+ spaces) - also not in code or link destinations
                emit_points.push(EmitPoint {
                    pos: mark.pos,
                    kind: EmitKind::SoftBreak,
                    end: mark.end,
                });
            }
        }

        // Sort by position (end events come after start events at same position)
        emit_points.sort_by_key(|p| {
            (
                p.pos,
                matches!(
                    p.kind,
                    EmitKind::CodeSpanEnd
                        | EmitKind::StrongEnd
                        | EmitKind::EmphasisEnd
                        | EmitKind::StrikethroughEnd
                        | EmitKind::SubscriptEnd
                        | EmitKind::SuperscriptEnd
                        | EmitKind::HighlightEnd
                        | EmitKind::LinkEnd
                        | EmitKind::ImageEnd
                ),
            )
        });

        // Build ranges to suppress (reference labels after link text)
        suppress_ranges.clear();
        suppress_ranges.reserve(resolved_ref_links.len());
        for link in resolved_ref_links {
            if link.end > link.text_end {
                suppress_ranges.push((link.text_end, link.end));
            }
        }

        // Emit events in order
        let mut skip_until = 0u32;
        let mut suppress_idx = 0usize;

        for point in emit_points.iter() {
            // Skip events inside suppressed ranges (e.g., reference labels)
            while suppress_idx < suppress_ranges.len()
                && point.pos >= suppress_ranges[suppress_idx].1
            {
                suppress_idx += 1;
            }
            if suppress_idx < suppress_ranges.len() {
                let (s, e) = suppress_ranges[suppress_idx];
                if point.pos > s && point.pos < e {
                    pos = pos.max(point.end);
                    continue;
                }
            }
            // Emit text before this point
            if point.pos > pos && point.pos > skip_until {
                let text_start = pos.max(skip_until);
                if point.pos > text_start {
                    events.push(InlineEvent::Text(Range::from_usize(
                        text_start as usize,
                        point.pos as usize,
                    )));
                }
            }

            match point.kind {
                EmitKind::CodeSpan { index } => {
                    let (content_start, content_end) = code_spans[index as usize].content_range();
                    let range = trim_span_padding(text, content_start, content_end);
                    events.push(InlineEvent::Code(range));
                    skip_until = range.end;
                }
                EmitKind::CodeSpanEnd => {
                    skip_until = point.end;
                }
                EmitKind::CodeSpanStart => {
                    // Skip the opening backticks
                    pos = point.end;
                }
                EmitKind::CodeContent(end) => {
                    let range = trim_span_padding(text, point.pos, end);
                    events.push(InlineEvent::Code(range));
                    skip_until = range.end;
                }
                EmitKind::EmphasisStart => {
                    events.push(InlineEvent::EmphasisStart);
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::EmphasisEnd => {
                    events.push(InlineEvent::EmphasisEnd);
                    skip_until = point.end;
                }
                EmitKind::StrongStart => {
                    events.push(InlineEvent::StrongStart);
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::StrongEnd => {
                    events.push(InlineEvent::StrongEnd);
                    skip_until = point.end;
                }
                EmitKind::StrikethroughStart => {
                    events.push(InlineEvent::StrikethroughStart);
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::StrikethroughEnd => {
                    events.push(InlineEvent::StrikethroughEnd);
                    skip_until = point.end;
                }
                EmitKind::SubscriptStart => {
                    events.push(InlineEvent::SubscriptStart);
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::SubscriptEnd => {
                    events.push(InlineEvent::SubscriptEnd);
                    skip_until = point.end;
                }
                EmitKind::SuperscriptStart => {
                    events.push(InlineEvent::SuperscriptStart);
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::SuperscriptEnd => {
                    events.push(InlineEvent::SuperscriptEnd);
                    skip_until = point.end;
                }
                EmitKind::HighlightStart => {
                    events.push(InlineEvent::HighlightStart);
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::HighlightEnd => {
                    events.push(InlineEvent::HighlightEnd);
                    skip_until = point.end;
                }
                EmitKind::Escape(ch) => {
                    events.push(InlineEvent::EscapedChar(ch));
                    skip_until = point.end;
                }
                EmitKind::HardBreak => {
                    events.push(InlineEvent::HardBreak);
                    skip_until = point.end;
                }
                EmitKind::SoftBreak => {
                    events.push(InlineEvent::SoftBreak);
                    skip_until = point.end;
                }
                EmitKind::LinkStart { link_index } => {
                    let link = &resolved_links[link_index as usize];
                    let (url_start, url_end, title_start, title_end) = (
                        link.url_start,
                        link.url_end,
                        link.title_start,
                        link.title_end,
                    );
                    events.push(InlineEvent::LinkStart {
                        url: Range::from_usize(url_start as usize, url_end as usize),
                        title: title_start
                            .map(|s| Range::from_usize(s as usize, title_end.unwrap() as usize)),
                    });
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::LinkStartRef { def_index } => {
                    events.push(InlineEvent::LinkStartRef { def_index });
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::LinkEnd => {
                    events.push(InlineEvent::LinkEnd);
                    skip_until = point.end;
                }
                EmitKind::ImageStart { link_index } => {
                    let link = &resolved_links[link_index as usize];
                    let (url_start, url_end, title_start, title_end) = (
                        link.url_start,
                        link.url_end,
                        link.title_start,
                        link.title_end,
                    );
                    events.push(InlineEvent::ImageStart {
                        url: Range::from_usize(url_start as usize, url_end as usize),
                        title: title_start
                            .map(|s| Range::from_usize(s as usize, title_end.unwrap() as usize)),
                    });
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::ImageStartRef { def_index } => {
                    events.push(InlineEvent::ImageStartRef { def_index });
                    pos = point.end;
                    skip_until = point.end;
                }
                EmitKind::ImageEnd => {
                    events.push(InlineEvent::ImageEnd);
                    skip_until = point.end;
                }
                EmitKind::AutolinkLiteral { kind } => {
                    let end = point.end;
                    events.push(InlineEvent::AutolinkLiteral {
                        url: Range::from_usize(point.pos as usize, end as usize),
                        kind,
                    });
                    skip_until = end;
                }
                EmitKind::AutolinkUrl { index } => {
                    let autolink = &autolinks[index as usize];
                    let (content_start, content_end) =
                        (autolink.content_start, autolink.content_end);
                    events.push(InlineEvent::Autolink {
                        url: Range::from_usize(content_start as usize, content_end as usize),
                        is_email: false,
                    });
                    skip_until = point.end;
                }
                EmitKind::AutolinkEmail { index } => {
                    let autolink = &autolinks[index as usize];
                    let (content_start, content_end) =
                        (autolink.content_start, autolink.content_end);
                    events.push(InlineEvent::Autolink {
                        url: Range::from_usize(content_start as usize, content_end as usize),
                        is_email: true,
                    });
                    skip_until = point.end;
                }
                EmitKind::HtmlRaw { end } => {
                    events.push(InlineEvent::Html(Range::from_usize(
                        point.pos as usize,
                        end as usize,
                    )));
                    skip_until = end;
                }
                EmitKind::FootnoteRef { def_index } => {
                    events.push(InlineEvent::FootnoteRef { def_index });
                    skip_until = point.end;
                }
                EmitKind::InlineFootnote { index } => {
                    let inline_note = &inline_footnotes[index as usize];
                    let (content_start, content_end) =
                        (inline_note.content_start, inline_note.content_end);
                    events.push(InlineEvent::InlineFootnote(Range::from_usize(
                        content_start as usize,
                        content_end as usize,
                    )));
                    skip_until = point.end;
                }
                EmitKind::MathInline { index } => {
                    let (start, end) = math_spans[index as usize].content_range();
                    events.push(InlineEvent::MathInline(trim_span_padding(text, start, end)));
                    skip_until = point.end;
                }
                EmitKind::MathDisplay { index } => {
                    let (start, end) = math_spans[index as usize].content_range();
                    events.push(InlineEvent::MathDisplay(trim_span_padding(
                        text, start, end,
                    )));
                    skip_until = point.end;
                }
            }

            pos = pos.max(point.end);
        }

        // Emit remaining text
        if pos < text_len {
            let start = pos.max(skip_until);
            if start < text_len {
                events.push(InlineEvent::Text(Range::from_usize(
                    start as usize,
                    text_len as usize,
                )));
            }
        }
    }
}

#[inline]
fn has_inline_specials(input: &[u8]) -> bool {
    simd::has_inline_specials::<false, false>(input)
}
#[inline]
fn has_inline_specials_highlight(input: &[u8]) -> bool {
    simd::has_inline_specials::<true, false>(input)
}
#[inline]
fn has_inline_specials_superscript(input: &[u8]) -> bool {
    simd::has_inline_specials::<false, true>(input)
}
#[inline]
fn has_inline_specials_highlight_superscript(input: &[u8]) -> bool {
    simd::has_inline_specials::<true, true>(input)
}

/// Check if text might contain autolink literal triggers.
/// Uses memchr for SIMD-accelerated scanning of rare byte patterns
/// instead of matching common letters like 'h' and 'w'.
#[inline]
fn has_autolink_candidates(input: &[u8]) -> bool {
    // The literal resolver rejects inputs shorter than four bytes. Short cells
    // otherwise pay for multiple search setups despite containing few bytes.
    if input.len() < 4 {
        return false;
    }
    if input.len() <= 16 {
        for (index, &byte) in input.iter().enumerate() {
            match byte {
                b'@' => return true,
                b':' if input[index..].starts_with(b"://") => return true,
                b'.' if index >= 3 && input[index - 3..index].eq_ignore_ascii_case(b"www") => {
                    return true;
                }
                _ => {}
            }
        }
        return false;
    }

    // Deliberately three separate single-byte passes: `@` and `:` are rare,
    // so their passes run at full single-needle SIMD speed. Folding the
    // needles into one memchr2/memchr3 pass executes fewer instructions but
    // measured slower on x86-64 AVX2 (frequent `.` stops throttle the
    // combined scan); see docs/reports/2026-07-25-profiling-hotspots.md.
    // Check for @ (email autolinks) — rare in normal prose
    if memchr(b'@', input).is_some() {
        return true;
    }
    // Check for :// (URL autolinks: http://, https://, ftp://) — colon is rare
    let mut pos = 0;
    while let Some(offset) = memchr(b':', &input[pos..]) {
        let idx = pos + offset;
        if idx + 2 < input.len() && input[idx + 1] == b'/' && input[idx + 2] == b'/' {
            return true;
        }
        pos = idx + 1;
    }
    // Check for www. / WWW. (www autolinks)
    pos = 0;
    while pos + 3 < input.len() {
        if let Some(offset) = memchr(b'.', &input[pos + 1..]) {
            let dot = pos + 1 + offset;
            if dot >= 3 {
                let s = dot - 3;
                if (input[s] | 0x20) == b'w'
                    && (input[s + 1] | 0x20) == b'w'
                    && (input[s + 2] | 0x20) == b'w'
                {
                    return true;
                }
            }
            pos = dot + 1;
        } else {
            break;
        }
    }
    false
}

#[inline]
fn has_inline_link_opener(input: &[u8]) -> bool {
    let mut pos = 0usize;
    while let Some(offset) = memchr(b']', &input[pos..]) {
        let idx = pos + offset;
        if idx + 1 < input.len() && input[idx + 1] == b'(' {
            return true;
        }
        pos = idx + 1;
    }
    false
}

#[inline]
fn has_inline_footnote_candidate(input: &[u8]) -> bool {
    let mut pos = 0usize;
    while let Some(offset) = memchr(b'^', &input[pos..]) {
        let caret = pos + offset;
        if input.get(caret + 1) == Some(&b'[') {
            return true;
        }
        pos = caret + 1;
    }
    false
}

impl Default for InlineParser {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(feature = "mdx")]
fn split_mdx_text_events(text: &[u8], events: &mut Vec<InlineEvent>, new_events_start: usize) {
    let original_events = events.split_off(new_events_start);

    for event in original_events {
        match event {
            InlineEvent::Text(range) => split_mdx_text_range(text, range, events),
            event => events.push(event),
        }
    }
}

#[cfg(feature = "mdx")]
fn split_mdx_text_range(text: &[u8], range: Range, events: &mut Vec<InlineEvent>) {
    let start = range.start_usize();
    let end = range.end_usize();
    let mut pos = start;
    let mut text_start = start;

    while pos < end {
        let event = match text[pos] {
            b'{' => crate::mdx::expr::find_expression_end(&text[pos..end]).map(|length| {
                (
                    InlineEvent::MdxExpression(Range::from_usize(pos, pos + length)),
                    pos + length,
                )
            }),
            b'<' => crate::mdx::jsx_tag::parse_jsx_tag(&text[pos..end]).map(|tag| {
                let tag_end = pos + tag.end_offset;
                let event = if tag.is_closing {
                    InlineEvent::MdxJsxClose(Range::from_usize(pos, tag_end))
                } else if tag.is_self_closing {
                    InlineEvent::MdxJsxSelfClose(Range::from_usize(pos, tag_end))
                } else {
                    InlineEvent::MdxJsxOpen(Range::from_usize(pos, tag_end))
                };
                (event, tag_end)
            }),
            _ => None,
        };

        if let Some((event, event_end)) = event {
            if text_start < pos {
                events.push(InlineEvent::Text(Range::from_usize(text_start, pos)));
            }
            events.push(event);
            pos = event_end;
            text_start = event_end;
        } else {
            pos += 1;
        }
    }

    if text_start < end {
        events.push(InlineEvent::Text(Range::from_usize(text_start, end)));
    }
}

/// A resolved footnote reference.
#[derive(Debug, Clone, Copy)]
struct FootnoteRef {
    /// Start position (the `[`).
    start: u32,
    /// End position (after `]`).
    end: u32,
    /// Index into the footnote store.
    def_index: u32,
}

#[derive(Debug, Clone, Copy)]
struct InlineFootnote {
    /// Start position (the `^`).
    start: u32,
    /// End position (after `]`).
    end: u32,
    /// Start of note content.
    content_start: u32,
    /// End of note content.
    content_end: u32,
}

/// Strip one padding space from each end of code or math content. A newline
/// counts as a space for this rule; rendering performs the actual normalization.
#[inline]
fn trim_span_padding(text: &[u8], start: u32, end: u32) -> Range {
    let mut start = start as usize;
    let mut end = end as usize;
    if end > start + 1 {
        let content = &text[start..end];
        let first_is_space = matches!(content[0], b' ' | b'\n');
        let last_is_space = matches!(content[content.len() - 1], b' ' | b'\n');
        let not_all_space = content.iter().any(|&byte| !matches!(byte, b' ' | b'\n'));
        if first_is_space && last_is_space && not_all_space {
            start += 1;
            end -= 1;
        }
    }
    Range::from_usize(start, end)
}

// Payload indices refer to parser-owned resolution records, which remain
// unchanged throughout emission. The temporary sort buffer need not copy them.
#[derive(Debug, Clone, Copy)]
struct EmitPoint {
    pos: u32,
    kind: EmitKind,
    end: u32,
}

#[derive(Debug, Clone, Copy)]
enum EmitKind {
    // A combined opener/content point; the closing point remains separate.
    CodeSpan { index: u32 },
    CodeSpanStart,
    CodeContent(u32),
    CodeSpanEnd,
    EmphasisStart,
    EmphasisEnd,
    StrongStart,
    StrongEnd,
    StrikethroughStart,
    StrikethroughEnd,
    SubscriptStart,
    SubscriptEnd,
    SuperscriptStart,
    SuperscriptEnd,
    HighlightStart,
    HighlightEnd,
    Escape(u8),
    HardBreak,
    SoftBreak,
    LinkStart { link_index: u32 },
    LinkStartRef { def_index: u32 },
    LinkEnd,
    ImageStart { link_index: u32 },
    ImageStartRef { def_index: u32 },
    ImageEnd,
    AutolinkUrl { index: u32 },
    AutolinkEmail { index: u32 },
    AutolinkLiteral { kind: links::AutolinkLiteralKind },
    HtmlRaw { end: u32 },
    FootnoteRef { def_index: u32 },
    InlineFootnote { index: u32 },
    MathInline { index: u32 },
    MathDisplay { index: u32 },
}

#[derive(Debug, Clone, Copy)]
struct HtmlSpan {
    start: u32,
    end: u32,
}

fn pos_in_spans(pos: u32, spans: &[HtmlSpan]) -> bool {
    let mut lo = 0usize;
    let mut hi = spans.len();
    while lo < hi {
        let mid = (lo + hi) / 2;
        let span = spans[mid];
        if pos < span.start {
            hi = mid;
        } else if pos >= span.end {
            lo = mid + 1;
        } else {
            return true;
        }
    }
    false
}

#[allow(clippy::too_many_arguments)]
fn find_html_spans_into(
    text: &[u8],
    code_spans: &[CodeSpan],
    autolinks: &[Autolink],
    code_ranges: &mut Vec<(usize, usize)>,
    autolink_ranges: &mut Vec<(usize, usize)>,
    spans: &mut Vec<HtmlSpan>,
) {
    spans.clear();

    code_ranges.clear();
    code_ranges.reserve(code_spans.len().saturating_sub(code_ranges.capacity()));
    code_ranges.extend(
        code_spans
            .iter()
            .map(|cs| (cs.opener_pos as usize, cs.closer_end as usize)),
    );
    code_ranges.sort_by_key(|(s, _)| *s);

    autolink_ranges.clear();
    autolink_ranges.reserve(autolinks.len().saturating_sub(autolink_ranges.capacity()));
    autolink_ranges.extend(
        autolinks
            .iter()
            .map(|al| (al.start as usize, al.end as usize)),
    );
    autolink_ranges.sort_by_key(|(s, _)| *s);

    let mut code_idx = 0usize;
    let mut autolink_idx = 0usize;

    let mut pos = 0usize;
    while let Some(offset) = memchr(b'<', &text[pos..]) {
        pos += offset;
        if is_escaped(text, pos) {
            pos += 1;
            continue;
        }

        if pos_in_ranges(pos, code_ranges, &mut code_idx)
            || pos_in_ranges(pos, autolink_ranges, &mut autolink_idx)
        {
            pos += 1;
            continue;
        }

        if let Some(end) = parse_inline_html(text, pos) {
            spans.push(HtmlSpan {
                start: pos as u32,
                end: end as u32,
            });
            pos = end;
        } else {
            pos += 1;
        }
    }
}

fn filter_html_spans_in_link_destinations(spans: &mut Vec<HtmlSpan>, links: &[Link]) {
    if spans.is_empty() || links.is_empty() {
        return;
    }
    spans.retain(|span| {
        !links.iter().any(|link| {
            let dest_start = link.text_end + 1;
            span.start >= dest_start && span.start < link.end
        })
    });
}

// Keep the range walk separate from the parser's early text-only return.
#[inline(never)]
fn filter_autolinks_in_code_spans(autolinks: &mut Vec<Autolink>, code_spans: &[CodeSpan]) {
    // Both sequences are ordered and code spans do not overlap.
    let mut code_idx = 0;
    autolinks.retain(|al| {
        while code_idx < code_spans.len() && {
            #[cfg(test)]
            record_range_probe(RangeProbe::AutolinkInCode);
            al.start >= code_spans[code_idx].closer_end
        } {
            code_idx += 1;
        }
        code_idx == code_spans.len() || al.start < code_spans[code_idx].opener_pos
    });
}

fn filter_html_spans_in_code_spans(spans: &mut Vec<HtmlSpan>, code_spans: &[CodeSpan]) {
    if spans.is_empty() || code_spans.is_empty() {
        return;
    }
    // HTML candidates and extracted code spans have increasing source offsets.
    let mut code_idx = 0;
    spans.retain(|span| {
        while code_idx < code_spans.len() && {
            #[cfg(test)]
            record_range_probe(RangeProbe::HtmlInCode);
            span.start >= code_spans[code_idx].closer_end
        } {
            code_idx += 1;
        }
        code_idx == code_spans.len() || span.start < code_spans[code_idx].opener_pos
    });
}

fn pos_in_ranges(pos: usize, ranges: &[(usize, usize)], idx: &mut usize) -> bool {
    while *idx < ranges.len() && pos >= ranges[*idx].1 {
        *idx += 1;
    }
    *idx < ranges.len() && pos >= ranges[*idx].0
}

fn pos_in_ranges_u32(pos: u32, ranges: &[(u32, u32)], idx: &mut usize) -> bool {
    while *idx < ranges.len() && pos >= ranges[*idx].1 {
        *idx += 1;
    }
    *idx < ranges.len() && pos >= ranges[*idx].0
}

/// Sort and coalesce link-like boundaries into disjoint half-open ranges.
///
/// Resolvers only need to know whether two delimiters occupy the same protected
/// region. Coalescing nested or overlapping ranges preserves that property and
/// makes logarithmic lookup possible.
fn normalize_link_boundaries(boundaries: &mut Vec<(u32, u32)>) {
    boundaries.sort_unstable_by_key(|&(start, end)| (start, end));

    let mut write = 0;
    for read in 0..boundaries.len() {
        let (start, end) = boundaries[read];
        if start >= end {
            continue;
        }

        if write > 0 && start < boundaries[write - 1].1 {
            boundaries[write - 1].1 = boundaries[write - 1].1.max(end);
        } else {
            boundaries[write] = (start, end);
            write += 1;
        }
    }
    boundaries.truncate(write);

    debug_assert!(
        boundaries
            .windows(2)
            .all(|pair| pair[0].0 < pair[0].1 && pair[0].1 <= pair[1].0)
    );
}

#[inline]
fn link_boundary_for(pos: u32, boundaries: &[(u32, u32)]) -> Option<usize> {
    let index = boundaries
        .partition_point(|&(start, _)| start <= pos)
        .checked_sub(1)?;
    (pos < boundaries[index].1).then_some(index)
}

#[inline]
fn same_link_boundary(a: u32, b: u32, boundaries: &[(u32, u32)]) -> bool {
    link_boundary_for(a, boundaries) == link_boundary_for(b, boundaries)
}

#[inline]
fn is_escaped(text: &[u8], pos: usize) -> bool {
    if pos == 0 {
        return false;
    }
    let mut backslashes = 0usize;
    let mut i = pos;
    while i > 0 && text[i - 1] == b'\\' {
        backslashes += 1;
        i -= 1;
    }
    backslashes % 2 == 1
}

fn parse_inline_html(text: &[u8], start: usize) -> Option<usize> {
    if text.get(start) != Some(&b'<') {
        return None;
    }
    if text.get(start + 1) == Some(&b'!') {
        if text[start..].starts_with(b"<!--") {
            return parse_html_comment(text, start);
        }
        if text[start..].starts_with(b"<![CDATA[") {
            return find_subsequence(text, start + 9, b"]]>").map(|end| end + 3);
        }
        return parse_html_declaration(text, start);
    }
    if text.get(start + 1) == Some(&b'?') {
        return find_subsequence(text, start + 2, b"?>").map(|end| end + 2);
    }
    parse_html_tag(text, start)
}

fn parse_html_comment(text: &[u8], start: usize) -> Option<usize> {
    let i = start + 4;
    if i >= text.len() {
        return None;
    }
    if text[i] == b'>' {
        return Some(i + 1);
    }
    if text[i] == b'-' && text.get(i + 1) == Some(&b'>') {
        return Some(i + 2);
    }
    find_subsequence(text, i, b"-->").map(|end| end + 3)
}

fn parse_html_declaration(text: &[u8], start: usize) -> Option<usize> {
    if text.get(start + 2).is_none_or(|b| !b.is_ascii_alphabetic()) {
        return None;
    }
    let mut i = start + 2;
    while i < text.len() && (text[i].is_ascii_alphanumeric() || text[i] == b'-') {
        i += 1;
    }
    while i < text.len() && is_html_whitespace(text[i]) {
        i += 1;
    }
    find_subsequence_byte(text, i, b'>').map(|end| end + 1)
}

fn parse_html_tag(text: &[u8], start: usize) -> Option<usize> {
    let len = text.len();
    let mut i = start + 1;
    if i >= len {
        return None;
    }

    let mut is_closing = false;
    if text[i] == b'/' {
        is_closing = true;
        i += 1;
    }

    if i >= len || !text[i].is_ascii_alphabetic() {
        return None;
    }
    i += 1;
    while i < len && (text[i].is_ascii_alphanumeric() || text[i] == b'-') {
        i += 1;
    }

    if is_closing {
        while i < len && is_html_whitespace(text[i]) {
            i += 1;
        }
        if i < len && text[i] == b'>' {
            return Some(i + 1);
        }
        return None;
    }

    loop {
        if i >= len {
            return None;
        }
        if text[i] == b'>' {
            return Some(i + 1);
        }
        if text[i] == b'/' {
            i += 1;
            return if i < len && text[i] == b'>' {
                Some(i + 1)
            } else {
                None
            };
        }
        if !is_html_whitespace(text[i]) {
            return None;
        }
        while i < len && is_html_whitespace(text[i]) {
            i += 1;
        }
        if i >= len {
            return None;
        }
        if text[i] == b'>' {
            return Some(i + 1);
        }
        if text[i] == b'/' {
            i += 1;
            return if i < len && text[i] == b'>' {
                Some(i + 1)
            } else {
                None
            };
        }

        if !is_attr_name_start(text[i]) {
            return None;
        }
        i += 1;
        while i < len && is_attr_name_char(text[i]) {
            i += 1;
        }

        let ws_start = i;
        while i < len && is_html_whitespace(text[i]) {
            i += 1;
        }

        if i < len && text[i] == b'=' {
            i += 1;
            while i < len && is_html_whitespace(text[i]) {
                i += 1;
            }
            if i >= len {
                return None;
            }
            let quote = text[i];
            if quote == b'"' || quote == b'\'' {
                i += 1;
                let value_start = i;
                while i < len && text[i] != quote {
                    i += 1;
                }
                if i >= len {
                    return None;
                }
                if i > value_start && text[i - 1] == b'\\' {
                    return None;
                }
                i += 1;
            } else {
                let mut had = false;
                while i < len && !is_html_whitespace(text[i]) {
                    let b = text[i];
                    if b == b'"' || b == b'\'' || b == b'=' || b == b'<' || b == b'>' || b == b'`' {
                        break;
                    }
                    had = true;
                    i += 1;
                }
                if !had {
                    return None;
                }
            }
        } else {
            i = ws_start;
        }
    }
}

#[inline]
fn is_html_whitespace(b: u8) -> bool {
    matches!(b, b' ' | b'\t' | b'\n' | b'\r' | b'\x0c')
}

#[inline]
fn is_attr_name_start(b: u8) -> bool {
    b.is_ascii_alphabetic() || b == b'_' || b == b':'
}

#[inline]
fn is_attr_name_char(b: u8) -> bool {
    is_attr_name_start(b) || b.is_ascii_digit() || b == b'.' || b == b'-'
}

fn find_subsequence(text: &[u8], start: usize, needle: &[u8]) -> Option<usize> {
    if needle.is_empty() || start >= text.len() || text.len() < needle.len() {
        return None;
    }
    text[start..]
        .windows(needle.len())
        .position(|w| w == needle)
        .map(|idx| start + idx)
}

fn find_subsequence_byte(text: &[u8], start: usize, needle: u8) -> Option<usize> {
    if start >= text.len() {
        return None;
    }
    text[start..]
        .iter()
        .position(|&b| b == needle)
        .map(|idx| start + idx)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn code_membership_preserves_html_boundaries_and_other_inline_syntax() {
        let mut options = crate::Options::commonmark();
        options.render_policy = crate::RenderPolicy::Trusted;
        let cases = [
            (
                r#"`<span title="`">` tail"#,
                r#"<p><code>&lt;span title=&quot;</code>&quot;&gt;` tail</p>"#,
            ),
            (
                r#"<span title="`">plain</span> `code`"#,
                r#"<p><span title="`">plain</span> <code>code</code></p>"#,
            ),
            (
                "`<Widget>` <https://example.test> `b`",
                r#"<p><code>&lt;Widget&gt;</code> <a href="https://example.test">https://example.test</a> <code>b</code></p>"#,
            ),
            (
                "` <Widget> ` and `` b ` c ``",
                "<p><code>&lt;Widget&gt;</code> and <code>b ` c</code></p>",
            ),
            (
                "`<Widget>&amp;` &amp;",
                "<p><code>&lt;Widget&gt;&amp;amp;</code> &amp;</p>",
            ),
        ];
        for (input, expected) in cases {
            assert_eq!(
                crate::to_html_with_options(input, &options),
                format!("{expected}\n"),
                "{input:?}"
            );
        }
    }

    #[test]
    fn code_membership_retains_enabled_literal_autolinks() {
        let mut options = crate::Options::commonmark();
        options.autolink_literals = true;
        assert_eq!(
            crate::to_html_with_options("Visit https://example.test with `<Widget>`.", &options),
            "<p>Visit <a href=\"https://example.test\">https://example.test</a> with <code>&lt;Widget&gt;</code>.</p>\n"
        );
    }

    #[test]
    fn code_html_membership_work_scales_linearly() {
        fn measure(repetitions: usize) -> [usize; 3] {
            let text =
                vec!["**bold** `<Widget>` `pending` <https://example.test>"; repetitions].join(" ");
            RANGE_PROBES.set([0; 3]);
            let html = crate::to_html_with_options(&text, &crate::Options::commonmark());
            let probes = RANGE_PROBES.get();
            assert_eq!(html.matches("<code>").count(), repetitions * 2);
            assert_eq!(html.matches("<a href=").count(), repetitions);
            assert_eq!(html.matches("<strong>").count(), repetitions);
            probes
        }

        let small = measure(64);
        let large = measure(128);
        // Each walk must contribute its own probes. A rewrite that bypasses one
        // counter must not be masked by the two remaining linear walks.
        for site in [
            RangeProbe::CodeOpenerInHtml,
            RangeProbe::AutolinkInCode,
            RangeProbe::HtmlInCode,
        ] {
            let small = small[site as usize];
            let large = large[site as usize];
            assert!(small > 0, "the mixed paragraph must exercise {site:?}");
            assert!(
                large <= small * 3,
                "{site:?} probes grew from {small} to {large}"
            );
        }
    }

    fn parse_inline(text: &str) -> Vec<InlineEvent> {
        let mut parser = InlineParser::new();
        let mut events = Vec::new();
        parser.parse(text.as_bytes(), None, true, &mut events);
        events
    }

    #[test]
    fn link_boundaries_are_normalized_for_binary_lookup() {
        let mut boundaries = vec![
            (20, 30),
            (8, 18),
            (5, 15),
            (30, 35),
            (40, 40),
            (2, 4),
            (9, 10),
        ];

        normalize_link_boundaries(&mut boundaries);

        assert_eq!(boundaries, vec![(2, 4), (5, 18), (20, 30), (30, 35)]);
        assert_eq!(link_boundary_for(3, &boundaries), Some(0));
        assert_eq!(link_boundary_for(4, &boundaries), None);
        assert_eq!(link_boundary_for(17, &boundaries), Some(1));
        assert_eq!(link_boundary_for(18, &boundaries), None);
        assert_eq!(link_boundary_for(29, &boundaries), Some(2));
        assert_eq!(link_boundary_for(30, &boundaries), Some(3));
        assert_eq!(link_boundary_for(35, &boundaries), None);
    }

    #[test]
    fn test_plain_text() {
        let events = parse_inline("hello world");
        assert_eq!(events.len(), 1);
        assert!(matches!(&events[0], InlineEvent::Text(_)));
    }

    #[test]
    fn test_code_span() {
        let input = "hello `code` world";
        let events = parse_inline(input);

        // Should have: Text("hello "), Code("code"), Text(" world")
        assert!(events.iter().any(|e| matches!(e, InlineEvent::Code(_))));

        for event in &events {
            if let InlineEvent::Code(range) = event {
                assert_eq!(range.slice(input.as_bytes()), b"code");
            }
        }
    }

    #[test]
    fn test_emphasis() {
        let events = parse_inline("hello *world*");

        assert!(
            events
                .iter()
                .any(|e| matches!(e, InlineEvent::EmphasisStart))
        );
        assert!(events.iter().any(|e| matches!(e, InlineEvent::EmphasisEnd)));
    }

    #[test]
    fn test_strong() {
        let events = parse_inline("hello **world**");

        assert!(events.iter().any(|e| matches!(e, InlineEvent::StrongStart)));
        assert!(events.iter().any(|e| matches!(e, InlineEvent::StrongEnd)));
    }

    #[test]
    fn test_backslash_escape() {
        let events = parse_inline("hello \\*world\\*");

        // Should have escaped characters instead of emphasis
        let escaped_count = events
            .iter()
            .filter(|e| matches!(e, InlineEvent::EscapedChar(_)))
            .count();
        assert_eq!(escaped_count, 2);
    }

    #[test]
    fn test_code_span_with_backticks() {
        let input = "`` `code` ``";
        let events = parse_inline(input);

        // Double backticks should contain single backticks
        for event in &events {
            if let InlineEvent::Code(range) = event {
                let content = std::str::from_utf8(range.slice(input.as_bytes())).unwrap();
                assert!(content.contains('`'));
            }
        }
    }

    #[test]
    fn test_emphasis_not_in_code() {
        let events = parse_inline("`*not emphasis*`");

        // Should not have emphasis events
        assert!(
            !events
                .iter()
                .any(|e| matches!(e, InlineEvent::EmphasisStart))
        );
    }

    #[test]
    fn test_image() {
        let input = "![alt](image.png)";
        let events = parse_inline(input);

        // Should have ImageStart and ImageEnd
        assert!(
            events
                .iter()
                .any(|e| matches!(e, InlineEvent::ImageStart { .. })),
            "No ImageStart found"
        );
        assert!(
            events.iter().any(|e| matches!(e, InlineEvent::ImageEnd)),
            "No ImageEnd found"
        );

        // Should NOT have a text event with just "!"
        for event in &events {
            if let InlineEvent::Text(range) = event {
                let text = range.slice(input.as_bytes());
                assert!(text != b"!", "Found standalone ! as text");
            }
        }
    }

    #[test]
    fn test_html_tag_with_newline_in_attributes() {
        let input = "<a foo=\"bar\" bam = 'baz <em>\"</em>'\n_boolean zoop:33=zoop:33 />";
        assert!(
            parse_inline_html(b"<a foo=\"bar\"\n_boolean />", 0).is_some(),
            "Expected basic multiline tag to parse"
        );
        assert!(
            parse_inline_html(b"<a foo=\"bar\" bam = 'baz <em>\"</em>'\n_boolean />", 0).is_some(),
            "Expected quoted attribute with inline tags to parse"
        );
        let end = parse_inline_html(input.as_bytes(), 0);
        assert!(
            end.is_some(),
            "Expected inline HTML parser to match the tag"
        );
        let events = parse_inline(input);
        let mut found = false;
        for event in events {
            if let InlineEvent::Html(range) = event
                && range.start == 0
            {
                let slice = range.slice(input.as_bytes());
                assert!(
                    slice.starts_with(b"<a "),
                    "Expected HTML span to start at <a>"
                );
                found = true;
                break;
            }
        }
        assert!(found, "Expected raw HTML tag to be parsed at start");
    }
}
